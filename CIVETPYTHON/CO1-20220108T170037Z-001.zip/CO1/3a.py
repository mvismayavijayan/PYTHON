list=[-5,10,0,-14,18,17]
print(list)
newlist=[x for x in list if x>0]
print("The positive numbers are:",newlist)