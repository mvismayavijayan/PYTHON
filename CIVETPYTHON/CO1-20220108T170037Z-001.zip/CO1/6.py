u=input("Enter the names:")
print(1)
count=0
for i in u:
    if i=="a":
        count+=1
print("The occurence of a is:",count)
