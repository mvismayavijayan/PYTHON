word=input("Enter the word:")
vowels=[x for x in word if x in ['a','e','i','o','u']]
print("The vowels in the words are:",vowels)