w=input("Enter a word:")
ord=[ord(x)for x in w]
print("The ordinal value is:",ord)