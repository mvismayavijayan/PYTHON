import math
a=int(input("Enter number1:"))
b=int(input("Enter number2:"))
gcd=math.gcd(a,b)
print(gcd)