list1=[1,2,3,4,5]
print(list1)
sum=0
for i in list1:
    sum=sum+i
    print("the sum is:",sum)